// 1. Selección de elementos del DOM
// Buscamos los nodos con los que el usuario va a interactuar utilizando sus selectores de clase o ID.
const formularioReporte = document.querySelector('.formulario');
const mensajeExito = document.getElementById('mensaje-exito');
const menuDesplegable = document.querySelector('.desplegable');

// 2. Interacción del Formulario (HU-24)
// Verificamos que el formulario exista en la página para evitar errores
if (formularioReporte) {
  // Escuchamos el evento 'submit' que se dispara al hacer clic en el botón de enviar
  formularioReporte.addEventListener('submit', (evento) => {
    
    // Evitamos el comportamiento por defecto (que el navegador viaje a confirmacion.html)
    evento.preventDefault();

    // Modificamos el DOM: cambiamos el estilo del mensaje para hacerlo visible
    mensajeExito.style.display = 'block';

    // Acción: Reseteamos (limpiamos) todos los campos del formulario
    formularioReporte.reset();

    // Modificamos el estado: ocultamos el mensaje automáticamente después de 5 segundos
    setTimeout(() => {
      mensajeExito.style.display = 'none';
    }, 5000);
  });
}

// 3. Interacción del Menú de Navegación (Mejora de UX)
// Escuchamos los clics en todo el documento para detectar si se hace clic fuera del menú
document.addEventListener('click', (evento) => {
  // Condición: Si el menú existe, está abierto (tiene el atributo 'open') y el clic NO fue dentro del menú
  if (menuDesplegable && menuDesplegable.hasAttribute('open') && !menuDesplegable.contains(evento.target)) {
    // Modificamos el DOM: removemos el atributo 'open' para cerrar el submenú
    menuDesplegable.removeAttribute('open');
  }
});
